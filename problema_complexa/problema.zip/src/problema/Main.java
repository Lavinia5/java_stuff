package problema;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.Callable;

class Main {
    public static void main(String[] args) {
        CarRentalAdministrator admin = new CarRentalAdministrator();
        Car car1 = new Car("audi", 1500, 2009, 15000);
        Car car2 = new Car("bmw", 2000, 1889, 20000);
        Car car3 = new Car("mercedes", 1800, 2023, 1000);
        admin.addCar(car1);
        admin.addCar(car2);
        admin.addCar(car3);
        Customer customer1 = new Customer("John", "Lll", "66666", new Date(2022, 7, 1),
                new Date(2022, 7, 8), "Iasi", "Bucuresti");
        Customer customer2 = new Customer("Jane", "Lolo", "6666634", new Date(2022, 7, 5),
                new Date(2022, 7, 12), "Cluj", "Timisoara");
        admin.addCustomer(customer1);
        admin.addCustomer(customer2);
        admin.createRental(customer1, car1, new Date(2022,7,1), new Date(2022,7,8), "Iasi" , "Bucuresti");
        admin.createRental(customer2, car2, new Date(2022, 7, 5),new Date(2022,7,12), "Cluj", "Timisoara");
        Date startDate = new Date(2022, 7, 1);
        Date endDate = new Date(2022, 7, 15);
        String rentalCity = "Iasi";
        String returnCity = " Bucuresti";
        ArrayList<Car> availableCars = admin.getAvailableCars(startDate,endDate,rentalCity,returnCity);
        System.out.println("Availab{le cars: ");
        for (Car car : availableCars){
            System.out.println(car.getBrand());
            Generic<Car> car9 = new Generic<>();
            Generic<Customer> customer9 = new Generic<>();
            car9.setObj(car1);
    }
    }
}