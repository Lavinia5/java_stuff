package problema;

public class Generic<T>{
    T obj;

    public void setObj(T obj) {
        this.obj = obj;
    }
    public T getObj(){
     return obj;
    }
}
